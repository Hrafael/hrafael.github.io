<!DOCTYPE html>
<!--[if lte IE 7 ]>   <html class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>   <html class="no-js ie8"> <![endif]-->
<!--[if (gt IE 8)|!(IE)]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <!-- Version 1 -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    
    
    <title>Page Not Found | DUKE</title>
    
  
    
    <meta name="description" content="" />
    
    
    <link rel="canonical" href="" />
        
    
    
  <link rel="shortcut icon" href="//cdn.shopify.com/s/files/1/0238/8255/t/4/assets/favicon.ico?14125368444965348588" type="images/x-icon">
    
    
    
    
<meta property="og:site_name" content="DUKE" />

    <meta property="og:type" content="website" />
    
    

    
    
    
        
        
        
        
        
    
        
        
        
        
        
            <link href="//fonts.googleapis.com/css?family=Quantico" rel="stylesheet" type="text/css">
        
    
        
        
        
        
        
            <link href="//fonts.googleapis.com/css?family=Quantico" rel="stylesheet" type="text/css">
        
    
        
        
        
        
        
            <link href="//fonts.googleapis.com/css?family=Quantico" rel="stylesheet" type="text/css">
        
    
        
        
        
        
        
    
    
    <link href="//cdn.shopify.com/s/files/1/0238/8255/t/4/assets/flexslider.css?14125368444965348588" rel="stylesheet" type="text/css"  media="all"  />
    <link href="//cdn.shopify.com/s/files/1/0238/8255/t/4/assets/jquery.fancybox-1.3.4.css?14125368444965348588" rel="stylesheet" type="text/css"  media="all"  />
    <link href="//cdn.shopify.com/s/files/1/0238/8255/t/4/assets/styles.css?14125368444965348588" rel="stylesheet" type="text/css"  media="all"  />
    
    
    
    <script src="//cdn.shopify.com/s/assets/themes_support/option_selection-87ab3c47afdd94e7292ed3925ae1bc31.js" type="text/javascript"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js" type="text/javascript"></script>
    <script src="//cdn.shopify.com/s/files/1/0238/8255/t/4/assets/jquery.imagesloaded.js?14125368444965348588" type="text/javascript"></script>
    <script src="//cdn.shopify.com/s/files/1/0238/8255/t/4/assets/jquery.flexslider-min.js?14125368444965348588" type="text/javascript"></script>
    <script src="//cdn.shopify.com/s/files/1/0238/8255/t/4/assets/jquery.fancybox-1.3.4.pack.js?14125368444965348588" type="text/javascript"></script>
<script>
Shopify.money_format = '<span class="money">&pound;{{amount}}</span>';
</script>
    <script src="//cdn.shopify.com/s/files/1/0238/8255/t/4/assets/main.js?14125368444965348588" type="text/javascript"></script>


<style type="text/css">




.slide.full-width-image .overlay-text .text-1 span {
    background: rgba(255, 255, 255, 0.5);
}

</style>

    <script>
//<![CDATA[
      var Shopify = Shopify || {};
      Shopify.shop = "duke-16.myshopify.com";
      Shopify.theme = {"name":"simmy14june","id":4431461,"theme_store_id":null,"role":"main"};

//]]>
</script>



<script id="__st">
//<![CDATA[
var __st={"a":2388255,"offset":-14400,"reqid":"0fcd2e75-b1e4-46a4-8610-6a7539f743a9","pageurl":"duke-16.myshopify.com\/restserver.php","u":"39e1d2430d03"};
//]]>
</script>
<script>
//<![CDATA[
      (function() {
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true;
        s.src = '//cdn.shopify.com/s/javascripts/shopify_stats.js?v=6';
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
      })();

//]]>
</script>
<script type="text/javascript">
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-42308061-1', 'auto', {'allowLinker': true});ga('send', 'pageview');
      (function(){
        ga('require', 'linker');
        function addListener(element, type, callback) {
          if (element.addEventListener) {
            element.addEventListener(type, callback);
          }
          else if (element.attachEvent) {
            element.attachEvent('on' + type, callback);
          }
        }
        function decorate(event) {
          event = event || window.event;
          var target = event.target || event.srcElement;
          if (target && (target.action || target.href)) {
            ga(function (tracker) {
              var linkerParam = tracker.get('linkerParam');
              document.cookie = '_shopify_ga=' + linkerParam + '; ' + 'path=/';
            });
          }
        }
        addListener(window, 'load', function(){
          for (var i=0; i<document.forms.length; i++) {
            if(document.forms[i].action && document.forms[i].action.indexOf('/cart') >= 0) {
              addListener(document.forms[i], 'submit', decorate);
            }
          }
          for (var i=0; i<document.links.length; i++) {
            if(document.links[i].href && document.links[i].href.indexOf('/checkout') >= 0) {
              addListener(document.links[i], 'click', decorate);
            }
          }
        })
      }());
    </script><script type="text/javascript" src="//cdn.shopify.com/s/assets/themes_support/ga_urchin_forms-7ada6895033623ac31caa5468381c85a.js"></script>

</head>

<body class="template-404">
  <div id="pageheader">
    <div id="mobile-header" class="cf">
      <button class="notabutton mobile-nav-toggle">Menu<span></span><span></span><span></span></button>
    </div>

        <div class="logo-area logo-pos- cf">
            
            
            
            <div class="logo container">
                <a href="/" title="DUKE">
                
                    <span class="logotext">DUKE</span>
                
                </a>
            </div><!-- /#logo -->
            
            
            <div class="util-area">
                <div class="search-box elegant-input">
                  
                  
                  <form class="search-form" action="/search" method="get">
                    <i></i>
                    <input type="text" name="q" placeholder="Try typing 'skate' here..."/>
                    <input type="submit" value="&rarr;" />
                  </form>
                </div>
                
                <div class="utils">
                    
                        <div class="social-links">
    
    
    <ul>
    
    
    
        
        <li class="facebook"><a href="" target="_blank" title="Facebook">Facebook</a></li>
        
    
    
    
        
        <li class="twitter"><a href="" target="_blank" title="Twitter">Twitter</a></li>
        
    
    
    
    
    
    
        
        <li class="pinterest"><a href="" target="_blank" title="Pinterest">Pinterest</a></li>
        
    
    
    
        
        <li class="google"><a href="" target="_blank" title="Google+">Google+</a></li>
        
    
    
    
        
        <li class="instagram"><a href="" target="_blank" title="Instagram">Instagram</a></li>
        
    
    
    
    
    
    
    
    
    
    
    
    
        
        <li class="tumblr"><a href="" target="_blank" title="Tumblr">Tumblr</a></li>
        
    
    </ul>
</div>

                    
                  
                    <div class="cart-summary">
                        <a href="/cart" class="cart-count button">
                            Cart (0)
                        </a>
                      
                      
<div class="switcher">
  <span class="selected-currency">
    GBP
  </span>
  <div class="switcher-drop">
    <div class="inner">
      <label for="currencies">Pick a currency</label>
      <select id="currencies" name="currencies">
        
        
        <option value="GBP" selected="selected">GBP</option>
        
        
        
        
        <option value="CAD">CAD</option>
        
        
        
        <option value="USD">USD</option>
        
        
      </select>
    </div>
  </div>
</div>

                    </div>
                </div><!-- /.utils -->
            </div><!-- /.util-area -->
            
            
            
        </div><!-- /.logo-area -->
    </div><!-- /#pageheader -->
    
    
    
    <div id="main-nav" class="nav-row">
      <div class="mobile-features">
        <form class="mobile-search" action="/search" method="get">
          <i></i>
          <input type="text" name="q" placeholder="Try typing 'skate' here..."/>
          <input class="notabutton" type="submit" value="&rarr;" />
        </form>
        <button class="mobile-nav-toggle button compact">X</button>
      </div>
      <div class="multi-level-nav">
    <div class="tier-1">
        





<ul data-menu-handle="main-menu">

    <li>
        <a href="/">Home</a>
        
        
        
        
        



    </li>

    <li>
        <a href="/collections//collections/all">Collections</a>
        
        
        
        
        





<ul data-menu-handle="collections">

    <li>
        <a href="/collections/">All Collections</a>
        
        
        
        
        



    </li>

    <li>
        <a href="/collections/sale">Sale</a>
        
        
        
        
        



    </li>

    <li>
        <a href="/collections/our-picks">Our Picks</a>
        
        
        
        
        



    </li>

    <li>
        <a href="/collections/new-arrivals">New Arrivals</a>
        
        
        
        
        



    </li>

    <li>
        <a href="/collections/all">All Skateboards</a>
        
        
        
        
        



    </li>

</ul>


    </li>

    <li>
        <a href="/blogs/news">Blog</a>
        
        
        
        
        



    </li>

    <li>
        <a href="/pages/about-us">About Us</a>
        
        
        
        
        



    </li>

    <li>
        <a href="#">Theme Features</a>
        
        
        
        
        





<ul data-menu-handle="theme-features">

    <li>
        <a href="/pages/theme-features">Feature List</a>
        
        
        
        
        



    </li>

    <li>
        <a href="/pages/how-to-set-up-shopify-theme-symmetry">Theme Setup</a>
        
        
        
        
        



    </li>

    <li>
        <a href="/pages/contact-us">Contact Us</a>
        
        
        
        
        



    </li>

    <li>
        <a href="#">Our Other Themes</a>
        
        
        
        
        





<ul data-menu-handle="our-other-themes">

    <li>
        <a href="http://salt-yard.myshopify.com/">Salt Yard</a>
        
        
        
        
        



    </li>

    <li>
        <a href="http://beatnik-5.myshopify.com/">Beatnik</a>
        
        
        
        
        



    </li>

    <li>
        <a href="http://chantilly.myshopify.com/">Chantilly</a>
        
        
        
        
        



    </li>

</ul>


    </li>

</ul>


    </li>

</ul>


        
        
    
        <ul>
            <li class="account-links">
                
                    
                        <span class="register"><a href="/account/register" id="customer_register_link">Register</a></span> <span class="slash">/</span>
                    
                    <span class="login"><a href="/account/login" id="customer_login_link">Login</a></span>
                
            </li>
        </ul>
    
    
        
    </div>
</div>
    </div><!-- /#main-nav -->
    
    <div id="content">
        
        
        
        
        
            <div class="container cf">
                <div class="page-header">
    <h1 class="majortitle">Page not found</h1>
</div>
<div class="row-spacing align-centre">
    <p>You may want to return to the <a href="/">home page</a> or <a href="/search">try a search</a>.</p>
</div>
            </div><!-- /.container -->
        
    </div><!-- /#content -->
    
  <div id="pagefooter">
    
    
    
    <div class="nav-row">
        <div class="multi-level-nav">
    <div class="tier-1">
        





<ul data-menu-handle="footer">

    <li>
        <a href="/search">Search</a>
        
        
        
        
        



    </li>

    <li>
        <a href="/pages/about-us">About Us</a>
        
        
        
        
        



    </li>

</ul>


        
        
        
    </div>
</div>
    </div><!-- /.nav-row -->
    
    
    <div class="lower cf">
        <div class="copyright">
            
            <img src="//cdn.shopify.com/s/files/1/0238/8255/t/4/assets/logo_small.png?14125368444965348588" alt="DUKE" />
            
          <span class="copy">&copy; Copyright 2015 <a href="/">DUKE.</a></span>
            
            Theme by <a href="http://www.cleanthemes.co.uk" target="_blank">Clean Themes.</a>
            
            <a href="http://www.shopify.co.uk/website/templates" rel="nofollow" target="_blank">Website template by Shopify</a>
        </div><!-- /.copyright -->
        
        <div class="interact">
            
                <div class="signup-form-cont">
    <div class="signup-form">
    
        <form accept-charset="UTF-8" action="/contact" class="contact-form" method="post"><input name="form_type" type="hidden" value="customer" /><input name="utf8" type="hidden" value="✓" />
            
                    <input type="hidden" id="contact_tags" name="contact[tags]" value="prospect,newsletter"/>
                    <label for="mailinglist_email">Sign Up</label>
                    <input type="email" placeholder="Email Address" class="required" value="" id="mailinglist_email" name="contact[email]" /><input class="compact" type="submit" value="→" />
                
            
        </form>
    
    </div>
</div>
            
        </div><!-- /.interact -->
        
        <div class="payment-methods">
            
            <ul>
                <li class="pay-paypal">PayPal</li>
                <li class="pay-visa">Visa</li>
                <li class="pay-mastercard">Mastercard</li>
                <li class="pay-amex">Amex</li>
                
                
                <li class="pay-maestro">Maestro</li>
                
                
            </ul>
                        
        </div>
    </div>
    
</div><!-- /#pagefooter -->
  

<script src="/services/javascripts/currencies.js" type="text/javascript"></script>
<script src="//cdn.shopify.com/s/files/1/0238/8255/t/4/assets/jquery.currencies.min.js?14125368444965348588" type="text/javascript"></script>

<script>


Currency.format = 'money_format';


var shopCurrency = 'GBP';

/* Sometimes merchants change their shop currency, let's tell our JavaScript file */
Currency.money_with_currency_format[shopCurrency] = "\u0026pound;{{amount}} GBP";
Currency.money_format[shopCurrency] = "\u0026pound;{{amount}}";
  
/* Default currency */
var defaultCurrency = 'GBP' || shopCurrency;
  
/* Cookie currency */
var cookieCurrency = Currency.cookie.read();

/* Fix for customer account pages */
jQuery('span.money span.money').each(function() {
  jQuery(this).parents('span.money').removeClass('money');
});

/* Saving the current price */
jQuery('span.money').each(function() {
  jQuery(this).attr('data-currency-GBP', jQuery(this).html());
});

// If there's no cookie.
if (cookieCurrency == null) {
  if (shopCurrency !== defaultCurrency) {
    Currency.convertAll(shopCurrency, defaultCurrency);
  }
  else {
    Currency.currentCurrency = defaultCurrency;
  }
}
// If the cookie value does not correspond to any value in the currency dropdown.
else if (jQuery('[name=currencies]').size() && jQuery('[name=currencies] option[value=' + cookieCurrency + ']').size() === 0) {
  Currency.currentCurrency = shopCurrency;
  Currency.cookie.write(shopCurrency);
}
else if (cookieCurrency === shopCurrency) {
  Currency.currentCurrency = shopCurrency;
}
else {
  Currency.convertAll(shopCurrency, cookieCurrency);
}

jQuery('[name=currencies]').val(Currency.currentCurrency).change(function() {
  var newCurrency = jQuery(this).val();
  Currency.convertAll(Currency.currentCurrency, newCurrency);
  jQuery('.selected-currency').text(Currency.currentCurrency);
});

var original_selectCallback = window.selectCallback;
var selectCallback = function(variant, selector) {
  original_selectCallback(variant, selector);
  Currency.convertAll(shopCurrency, jQuery('[name=currencies]').val());
  jQuery('.selected-currency').text(Currency.currentCurrency);
};

jQuery('.selected-currency').text(Currency.currentCurrency);

  //Show dropdown when currency clicked
  $('#pageheader .utils .cart-summary .switcher').bind('click', function(){
    $(this).toggleClass('show-drop');
  });
  
</script>


  
  <script>
jQuery('a[href^="http"]').not('a[href^="http://duke-16.myshopify.com"]').attr('target', '_top');
</script>
</body>
</html>